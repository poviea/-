package step03.value;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/value")
public class ValuePrint extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ValuePrint() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// post 방식에서 한글 처리
		String[] values = request.getParameterValues("like");

		// 요청사항
		// WebContent - view - choice.html에서 선택한 값들을 console에 출력
		System.out.println("doPost()");
		
//		String like = request.getParameter("like");
//		System.out.println(like);
		request.setCharacterEncoding("UTF-8");
		for(String value : values) {
			System.out.println(value);
		}
		
	}

}
