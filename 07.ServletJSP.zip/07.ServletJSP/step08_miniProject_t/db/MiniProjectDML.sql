insert into board values('helpMe1', 'bbs', 'bbs@naver.com', '살려주세요11', 'bbs1234', '2022-09-21', 0);
insert into board values('helpMe2', 'kmu', 'kmu@naver.com', '살려주세요22', 'kmu1234', '2022-09-21', 0);
insert into board values('helpMe3', 'jhj', 'jhj@naver.com', '살려주세요33', 'jhj1234', '2022-09-21', 0);