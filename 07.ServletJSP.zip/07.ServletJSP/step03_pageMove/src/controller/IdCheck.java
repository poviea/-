package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.CustomerDAO;
import model.domain.Customer;

@WebServlet("/check")
public class IdCheck extends HttpServlet {
	private static CustomerDAO customerDAO = CustomerDAO.getInstance();
	
	
	String value;
	
	@Override
	public void init(ServletConfig config) {
		System.out.println("Check : init()");
		String value = config.getInitParameter("testParameter");
		System.out.println(value);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String env = this.getInitParameter("charset");
		request.setCharacterEncoding(env);
		
		// 시나리오
		/*
		 * 1) add.html (회원가입)
		 *  - form - input : id, pw, grade, input : submit 가입
		 * 2) /check (회원 검증)
		 * 	- 입력된 아이디가 가상의 db 존재한다면 ! - 회원 가입 실패 : fail(Servlet) --> JSP
		 * 		- "회원 가입 실패: 동일한 id 존재"
		 */
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String grade = request.getParameter("grade");
		
		Customer newCustomer = new Customer(id, pw, grade);
 
		boolean result = false;
		for(int i= 0; i < CustomerDAO.userData.size(); i++) {
			if (CustomerDAO.userData.get(i).getId().equals(id)) {
				result = true;
				break;
			}
		}
		
		if(result) {
			request.getRequestDispatcher("invalid").forward(request, response);
		} else {
			request.setAttribute("company", "IT");
			request.getRequestDispatcher("valid").forward(request, response);
		}
		
		
	}
}


