package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.DeptDAO;

@WebServlet("/dept")
public class DeptController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 시나리오 컨트롤로 -> 서비스 -> DAO 화면에서 deptno 값을 전달한다 DeptController(/dept) 전달받은 dept를
		 * 활용하여 DB에 접근한다 : DeptDAO : String getNameByDeptno(int deptno) 받은 결과 객체를 화면에
		 * 전달한다. : view.jsp (request.setAttribute("dname", dname)) : failView.jsp
		 */
		int deptno = Integer.parseInt(request.getParameter("deptno"));

		try {
			String dname = DeptDAO.getDnameByDeptno(deptno);

			if (dname != null) {
				request.setAttribute("dname", dname);
				
				System.out.println("---dname:before---");
				request.getRequestDispatcher("view.jsp").forward(request, response);
				System.out.println("---dname:after---");
			} else {
				request.setAttribute("dname", "존재하지 않는 부서");
//				request.getRequestDispatcher("view.jsp").forward(request, response);
				response.sendRedirect("failView.jsp");
			}

		} catch (Exception e) {
			System.out.println("---exception:before");
			response.sendRedirect("failView.jsp");
			System.out.println("---exception:before");
		} 
  
	}

}
