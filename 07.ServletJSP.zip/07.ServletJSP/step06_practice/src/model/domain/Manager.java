package model.domain;

// 롬복

public class Manager {
	// 멤버 변수
	
}
