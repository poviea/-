
package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class IdCheck
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/check" })
public class IdCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id = request.getParameter("id");
//		System.out.println(id);
		
		
		// step02 Session(HttpSession)
		// 생성 또는 이미 사용중인 session 정보 반환
		HttpSession session1 = request.getSession();
		System.out.println(session1.getId());
		
		session1.setAttribute("sessionId", id);
		session1.setAttribute("msg", "Session 학습");
		
		response.sendRedirect("save");
		
		
		
		//step01 Cookie
//		if(id != null) {
//			// 쿠키 객체 생성
//			Cookie cookie1 = new Cookie("stateId" , id );
//			
//			// 쿠키 설정: 클라이언트 시스템에 저장되는 잔존 시간 
//			cookie1.setMaxAge(60 * 60 * 24 * 365); // 1년 
//			
//			// 클라이언트 시스템에 저장 
//			response.addCookie(cookie1);
//			
//			response.sendRedirect("save");
//			
//			
//			
//		}
//		
//		
		
	}

}


