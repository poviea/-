package variable;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/var")
@WebServlet(urlPatterns = {"/var"}, initParams = {@WebInitParam(name = "charset", value = "UTF-8")})
public class VariableTest extends HttpServlet {
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		String env = config.getInitParameter("charset");
		System.out.println(env);
		super.init(config);	
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int num = 0;
		// 2명의 User가 현재의 서비스에 접속
		// 서비스 : user의 이름 : 1 ~ 10 출력
		// user 정보는 쿼리 스트링 전달 ? user = user1, user = user2, ...
		
//		String env = this.getInitParameter("charset");
//		request.setCharacterEncoding(env);
		
		response.setContentType("text/html;charset=UTF-8");
		
		String user = request.getParameter("user");
		
		PrintWriter out = response.getWriter();
		while(num < 10) {
			num++;
			out.println(user + " : " + num + "<br/>");
			out.flush();
			
			System.out.println(user + " : " + num);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		out.close();
	}
	

}
